package com.nacaoazul.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Calendar
import java.util.HashMap
import java.util.Locale
import java.util.TimeZone

/**
 * Dois cards de informação ao vivo:
 *  - tabela do Brasileirão (Cruzeiro sempre aparece, com vizinhos acima e abaixo)
 *  - próximo jogo do Cruzeiro com contagem regressiva
 * Dados vêm da API pública da ESPN. O último resultado fica salvo no aparelho
 * para aparecer na hora e para funcionar mesmo sem internet.
 */
class InfoCards(private val ctx: Context, private val handler: Handler) {

    private class Row(
        val rank: Int,
        val name: String,
        val played: Int,
        val gd: Int,
        val pts: Int,
        val isCruzeiro: Boolean
    )

    private class Game(
        val timeMs: Long,
        val home: String,
        val away: String,
        val live: Boolean,
        val comp: String
    )

    private companion object {
        const val CRUZEIRO_ID = "2022"
        const val BASE = "https://site.api.espn.com/apis"
        const val STANDINGS_URL = "$BASE/v2/sports/soccer/bra.1/standings"
        const val REFRESH_MS = 15 * 60 * 1000L
        const val VISIBLE_ROWS = 5
        // Campeonatos consultados para achar o próximo jogo (erros são ignorados)
        val LEAGUES = listOf(
            "bra.1" to "Brasileirão",
            "bra.copa_do_brasil" to "Copa do Brasil",
            "conmebol.libertadores" to "Libertadores",
            "conmebol.sudamericana" to "Sul-Americana"
        )
    }

    private val prefs = ctx.getSharedPreferences("info", Context.MODE_PRIVATE)

    val standingsView = LinearLayout(ctx)
    val gameView = FrameLayout(ctx)

    private lateinit var gTitle: TextView
    private lateinit var gMatch: TextView
    private lateinit var gDate: TextView
    private lateinit var gCount: TextView
    private lateinit var gComp: TextView

    private var game: Game? = null
    private var lastFetch = 0L

    private val ticker = object : Runnable {
        override fun run() {
            tickCountdown()
            if (System.currentTimeMillis() - lastFetch > REFRESH_MS) refresh()
            handler.postDelayed(this, 1000)
        }
    }

    init {
        buildStandingsShell()
        buildGameCard()
        // Mostra o que já estava salvo enquanto busca o novo
        prefs.getString("standings", null)?.let { applyStandings(it) } ?: renderStandings(null)
        prefs.getString("game", null)?.let { applyCachedGame(it) } ?: renderGame()
    }

    // ------------------------------------------------------------ ciclo

    fun start() {
        stop()
        handler.post(ticker)
    }

    fun stop() {
        handler.removeCallbacks(ticker)
    }

    // ------------------------------------------------------------ util

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private fun cardBg(): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(16).toFloat()
        g.setColor(Color.parseColor("#8C000F3D"))
        g.setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        return g
    }

    private fun text(s: String, sp: Float, color: String, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(Color.parseColor(color))
        t.includeFontPadding = false
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        if (bold) t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        return t
    }

    // ------------------------------------------------------------ tabela

    private fun buildStandingsShell() {
        standingsView.orientation = LinearLayout.VERTICAL
        standingsView.background = cardBg()
        standingsView.setPadding(dp(14), dp(8), dp(14), dp(8))
    }

    private fun cell(s: String, widthDp: Int, color: String, bold: Boolean, sp: Float): TextView {
        val t = text(s, sp, color, bold)
        t.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        t.layoutParams = LinearLayout.LayoutParams(dp(widthDp), ViewGroup.LayoutParams.MATCH_PARENT)
        return t
    }

    private fun renderStandings(rows: List<Row>?) {
        standingsView.removeAllViews()

        // Cabeçalho
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = text("BRASILEIRÃO", 10f, "#8FB0FF")
        title.letterSpacing = 0.2f
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        head.addView(cell("J", 26, "#8FB0FF", false, 10f))
        head.addView(cell("SG", 32, "#8FB0FF", false, 10f))
        head.addView(cell("PTS", 36, "#8FB0FF", false, 10f))
        standingsView.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16)))

        if (rows == null || rows.isEmpty()) {
            val t = text("Carregando tabela…", 12f, "#B9CBFF")
            t.gravity = Gravity.CENTER_VERTICAL
            standingsView.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)))
            return
        }

        val idx = rows.indexOfFirst { it.isCruzeiro }
        val start = if (idx < 0) 0 else (idx - VISIBLE_ROWS / 2).coerceIn(0, maxOf(0, rows.size - VISIBLE_ROWS))
        val end = minOf(rows.size, start + VISIBLE_ROWS)

        for (i in start until end) {
            val r = rows[i]
            val line = LinearLayout(ctx)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.setPadding(dp(4), 0, dp(4), 0)
            val color = if (r.isCruzeiro) "#FFFFFF" else "#D5E1FF"
            if (r.isCruzeiro) {
                val hl = GradientDrawable()
                hl.cornerRadius = dp(6).toFloat()
                hl.setColor(Color.parseColor("#734D86FF"))
                line.background = hl
            }
            val pos = text("${r.rank}", 12f, color, r.isCruzeiro)
            pos.gravity = Gravity.CENTER_VERTICAL
            line.addView(pos, LinearLayout.LayoutParams(dp(22), ViewGroup.LayoutParams.MATCH_PARENT))
            val name = text(r.name, 12f, color, r.isCruzeiro)
            name.gravity = Gravity.CENTER_VERTICAL
            line.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            line.addView(cell("${r.played}", 26, color, r.isCruzeiro, 12f))
            val gd = if (r.gd > 0) "+${r.gd}" else "${r.gd}"
            line.addView(cell(gd, 32, color, r.isCruzeiro, 12f))
            line.addView(cell("${r.pts}", 36, color, true, 12f))
            standingsView.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16)))
        }
    }

    private fun applyStandings(json: String) {
        try {
            val root = JSONObject(json)
            val entries = root.getJSONArray("children").getJSONObject(0)
                .getJSONObject("standings").getJSONArray("entries")
            val list = ArrayList<Row>()
            for (i in 0 until entries.length()) {
                val e = entries.getJSONObject(i)
                val team = e.getJSONObject("team")
                val stats = e.getJSONArray("stats")
                val m = HashMap<String, Double>()
                for (j in 0 until stats.length()) {
                    val s = stats.getJSONObject(j)
                    m[s.getString("name")] = s.optDouble("value", 0.0)
                }
                list.add(
                    Row(
                        (m["rank"] ?: (i + 1).toDouble()).toInt(),
                        team.optString("displayName"),
                        (m["gamesPlayed"] ?: 0.0).toInt(),
                        (m["pointDifferential"] ?: 0.0).toInt(),
                        (m["points"] ?: 0.0).toInt(),
                        team.optString("id") == CRUZEIRO_ID
                    )
                )
            }
            list.sortBy { it.rank }
            renderStandings(list)
        } catch (e: Exception) {
            renderStandings(null)
        }
    }

    // ------------------------------------------------------------ próximo jogo

    private fun buildGameCard() {
        val h = dp(112)
        val r = dp(16)

        val bg = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#0B3AA6"), Color.parseColor("#001B66"))
        )
        bg.cornerRadius = r.toFloat()
        gameView.background = bg
        gameView.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r.toFloat())
            }
        }
        gameView.clipToOutline = true

        // Imagem do clube à esquerda (proporção original 288x175)
        val imgW = h * 288 / 175
        val img = ImageView(ctx)
        img.setImageResource(R.drawable.cruzeiro_bg)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        gameView.addView(img, FrameLayout.LayoutParams(imgW, h, Gravity.START))

        // Esmaece a borda direita da imagem para encontrar o texto
        val fade = View(ctx)
        val fg = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.TRANSPARENT, Color.parseColor("#0A34A0"))
        )
        fade.background = fg
        gameView.addView(fade, FrameLayout.LayoutParams(imgW, h, Gravity.START))

        // Textos
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(dp(150), dp(8), dp(14), dp(8))

        gTitle = text("PRÓXIMO JOGO", 10f, "#9DB9FF")
        gTitle.letterSpacing = 0.2f
        gMatch = text("—", 15f, "#FFFFFF", true)
        gDate = text("", 12f, "#CFE0FF")
        gCount = text("", 22f, "#FFFFFF", true)
        gCount.typeface = Typeface.create("sans-serif-light", Typeface.BOLD)
        gComp = text("", 10f, "#9DB9FF")

        box.addView(gTitle)
        box.addView(gMatch)
        box.addView(gDate)
        box.addView(gCount)
        box.addView(gComp)
        gameView.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
    }

    private fun renderGame() {
        val g = game
        if (g == null) {
            gMatch.text = "Buscando jogo…"
            gDate.text = ""
            gCount.text = ""
            gComp.text = ""
            return
        }
        gMatch.text = "${g.home} x ${g.away}"
        val f = SimpleDateFormat("EEE, dd/MM '·' HH:mm", Locale("pt", "BR"))
        gDate.text = f.format(Calendar.getInstance().apply { timeInMillis = g.timeMs }.time)
        gComp.text = g.comp.uppercase()
        tickCountdown()
    }

    private fun tickCountdown() {
        val g = game ?: return
        val diff = g.timeMs - System.currentTimeMillis()
        if (g.live) {
            gCount.text = "AO VIVO"
            return
        }
        if (diff <= 0) {
            gCount.text = "COMEÇANDO"
            return
        }
        val s = diff / 1000
        val d = s / 86400
        val hh = (s % 86400) / 3600
        val mm = (s % 3600) / 60
        val ss = s % 60
        gCount.text = if (d > 0) {
            String.format(Locale.US, "%dd %02dh %02dm %02ds", d, hh, mm, ss)
        } else {
            String.format(Locale.US, "%02d:%02d:%02d", hh, mm, ss)
        }
    }

    private fun applyCachedGame(s: String) {
        try {
            val p = s.split("|")
            game = Game(p[0].toLong(), p[1], p[2], p[3] == "1", p[4])
        } catch (e: Exception) {
            game = null
        }
        renderGame()
    }

    private fun cacheGame(g: Game): String =
        "${g.timeMs}|${g.home}|${g.away}|${if (g.live) "1" else "0"}|${g.comp}"

    // ------------------------------------------------------------ rede

    private fun refresh() {
        lastFetch = System.currentTimeMillis()
        Thread {
            try {
                val s = http(STANDINGS_URL)
                prefs.edit().putString("standings", s).apply()
                handler.post { applyStandings(s) }
            } catch (e: Exception) {
                // sem internet: continua mostrando o que estava salvo
            }
            try {
                val g = findNextGame()
                if (g != null) {
                    prefs.edit().putString("game", cacheGame(g)).apply()
                    handler.post {
                        game = g
                        renderGame()
                    }
                }
            } catch (e: Exception) {
                // idem
            }
        }.start()
    }

    private fun http(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        try {
            if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun parseDate(s: String): Long? {
        for (p in listOf("yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'")) {
            try {
                val f = SimpleDateFormat(p, Locale.US)
                f.timeZone = TimeZone.getTimeZone("UTC")
                val d = f.parse(s)
                if (d != null) return d.time
            } catch (e: Exception) {
                // tenta o próximo formato
            }
        }
        return null
    }

    private fun parseEvent(e: JSONObject, comp: String): Game? {
        val c = e.optJSONArray("competitions")?.optJSONObject(0) ?: return null
        val state = c.optJSONObject("status")?.optJSONObject("type")?.optString("state")
            ?: e.optJSONObject("status")?.optJSONObject("type")?.optString("state")
            ?: "pre"
        if (state == "post") return null
        val t = parseDate(e.optString("date")) ?: return null
        if (state == "pre" && t < System.currentTimeMillis() - 3 * 3600_000L) return null
        val comps = c.optJSONArray("competitors") ?: return null
        var home = ""
        var away = ""
        var hasCru = false
        for (i in 0 until comps.length()) {
            val x = comps.getJSONObject(i)
            val team = x.optJSONObject("team")
            val name = team?.optString("displayName") ?: ""
            val id = team?.optString("id") ?: x.optString("id")
            if (id == CRUZEIRO_ID) hasCru = true
            if (x.optString("homeAway") == "home") home = name else away = name
        }
        if (!hasCru || home.isEmpty() || away.isEmpty()) return null
        return Game(t, home, away, state == "in", comp)
    }

    private fun findNextGame(): Game? {
        var best: Game? = null

        // 1) agenda do time em cada campeonato
        for ((slug, compName) in LEAGUES) {
            try {
                val root = JSONObject(http("$BASE/site/v2/sports/soccer/$slug/teams/$CRUZEIRO_ID/schedule"))
                val ev = root.optJSONArray("events") ?: continue
                for (i in 0 until ev.length()) {
                    val g = parseEvent(ev.getJSONObject(i), compName) ?: continue
                    val b = best
                    if (b == null || g.timeMs < b.timeMs) best = g
                }
            } catch (e: Exception) {
                // campeonato sem dados: segue
            }
        }
        if (best != null) return best

        // 2) plano B: placar do Brasileirão nos próximos 150 dias
        try {
            val f = SimpleDateFormat("yyyyMMdd", Locale.US)
            val now = Calendar.getInstance()
            val later = Calendar.getInstance()
            later.add(Calendar.DAY_OF_YEAR, 150)
            val url = "$BASE/site/v2/sports/soccer/bra.1/scoreboard?dates=" +
                f.format(now.time) + "-" + f.format(later.time) + "&limit=400"
            val ev = JSONObject(http(url)).optJSONArray("events")
            if (ev != null) {
                for (i in 0 until ev.length()) {
                    val g = parseEvent(ev.getJSONObject(i), "Brasileirão") ?: continue
                    val b = best
                    if (b == null || g.timeMs < b.timeMs) best = g
                }
            }
        } catch (e: Exception) {
            // sem plano C
        }
        return best
    }
}
