package com.nacaoazul.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import java.util.Random

/**
 * Fundo da tela inicial: degradê em azul cruzeirense com a constelação do
 * Cruzeiro do Sul (as cinco estrelas) em destaque suave no canto direito.
 */
class SkyView(context: Context) : View(context) {

    companion object {
        // Para ajustar o tom do azul, mexa só aqui.
        val BLUE_DEEP: Int = Color.parseColor("#000B33")
        val BLUE_MID: Int = Color.parseColor("#00227A")
        val BLUE_MAIN: Int = Color.parseColor("#0033A0")
        val BLUE_GLOW: Int = Color.parseColor("#4D6FA8FF")
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val density = context.resources.displayMetrics.density

    // 30 estrelinhas aleatórias (x, y, tamanho), sempre as mesmas
    private val tiny = FloatArray(90).also { arr ->
        val rnd = Random(7)
        for (i in arr.indices) arr[i] = rnd.nextFloat()
    }

    // Posição das 5 estrelas do Cruzeiro do Sul (0..1 dentro da área) e tamanho relativo
    private val crux = arrayOf(
        floatArrayOf(0.50f, 0.04f, 1.00f), // topo (Gacrux)
        floatArrayOf(0.10f, 0.42f, 0.85f), // esquerda (Delta)
        floatArrayOf(0.90f, 0.50f, 1.00f), // direita (Mimosa)
        floatArrayOf(0.56f, 0.96f, 1.20f), // base (Acrux)
        floatArrayOf(0.70f, 0.70f, 0.55f)  // pequena (Epsilon)
    )

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        // Degradê base
        paint.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(BLUE_DEEP, BLUE_MID, BLUE_MAIN),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)

        // Brilho no canto direito, atrás da constelação
        paint.shader = RadialGradient(
            w * 0.80f, h * 0.30f, w * 0.50f,
            BLUE_GLOW, Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)

        // Estrelinhas de fundo
        paint.shader = null
        for (i in 0 until 30) {
            val x = tiny[i * 3] * w
            val y = tiny[i * 3 + 1] * h * 0.65f
            val r = (1f + tiny[i * 3 + 2] * 2.2f) * density
            paint.color = Color.argb(60 + (tiny[i * 3 + 2] * 110).toInt(), 255, 255, 255)
            canvas.drawCircle(x, y, r, paint)
        }

        // Constelação do Cruzeiro do Sul
        val areaLeft = w * 0.64f
        val areaTop = h * 0.04f
        val areaW = w * 0.30f
        val areaH = h * 0.46f
        val base = areaW * 0.085f
        for (s in crux) {
            val cx = areaLeft + s[0] * areaW
            val cy = areaTop + s[1] * areaH
            val r = base * s[2]

            // halo
            paint.shader = RadialGradient(
                cx, cy, r * 2.6f,
                Color.argb(70, 255, 255, 255), Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, r * 2.6f, paint)

            // estrela
            paint.shader = null
            paint.color = Color.argb(170, 255, 255, 255)
            drawStar(canvas, cx, cy, r)
        }

        // Escurece a parte de baixo para os apps ficarem legíveis
        paint.shader = LinearGradient(
            0f, h * 0.45f, 0f, h,
            Color.TRANSPARENT, Color.argb(190, 0, 6, 30),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, h * 0.45f, w, h, paint)
        paint.shader = null
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        path.reset()
        for (i in 0 until 10) {
            val rad = if (i % 2 == 0) r else r * 0.42f
            val a = Math.PI / 5.0 * i - Math.PI / 2.0
            val x = cx + (rad * Math.cos(a)).toFloat()
            val y = cy + (rad * Math.sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, paint)
    }
}
