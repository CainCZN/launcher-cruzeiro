package com.nacaoazul.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class MainActivity : Activity() {

    private class AppItem(
        val label: String,
        val pkg: String,
        val icon: Drawable,
        val banner: Drawable?,
        val intent: Intent
    )

    private companion object {
        const val MAX_FAVS = 6
        const val PREFS = "prefs"
        const val KEY_FAV = "fav"
        val MP = ViewGroup.LayoutParams.MATCH_PARENT
        val WC = ViewGroup.LayoutParams.WRAP_CONTENT
        // Apps que viram favoritos na primeira abertura (se estiverem instalados)
        val PREFERRED = listOf(
            "com.stremio.one",
            "com.globo.globotv",
            "com.disney.disneyplus",
            "com.google.android.youtube.tv",
            "com.netflix.ninja",
            "com.amazon.amazonvideo.livingroom",
            "app.aksports.live",
            "com.sportzx.live",
            "cinetvflix.top"
        )
    }

    private lateinit var favRow: LinearLayout
    private lateinit var allRow: LinearLayout
    private lateinit var greeting: TextView
    private lateinit var info: InfoCards
    private var apps: List<AppItem> = emptyList()
    private var lastFocusPkg: String? = null

    private var cardW = 0
    private var cardH = 0

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        updateGreeting()
        loadApps()
        render()
        info.start()
    }

    override fun onPause() {
        info.stop()
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Apertou Home de novo: volta ao primeiro favorito
        lastFocusPkg = null
        render()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // Na tela inicial o Voltar não faz nada
    }

    // ---------------------------------------------------------------- interface

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val screenW = resources.displayMetrics.widthPixels
        val pad = dp(48)
        val gap = dp(14)
        cardW = (screenW - 2 * pad - 2 * dp(10) - (MAX_FAVS - 1) * gap) / MAX_FAVS
        cardH = (cardW * 0.62f).toInt()

        val root = FrameLayout(this)
        root.addView(SkyView(this), FrameLayout.LayoutParams(MP, MP))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, dp(24), pad, dp(14))
        col.clipChildren = false
        col.clipToPadding = false
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.isVerticalScrollBarEnabled = false
        scroll.clipChildren = false
        scroll.clipToPadding = false
        scroll.addView(col, ViewGroup.LayoutParams(MP, WC))
        root.addView(scroll, FrameLayout.LayoutParams(MP, MP))

        // Cabeçalho: relógio + data à esquerda, saudação à direita
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.TOP

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL

        val clock = TextClock(this)
        clock.format24Hour = "HH:mm"
        clock.format12Hour = "HH:mm"
        clock.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 52f)
        clock.setTextColor(Color.WHITE)
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        left.addView(clock)

        val date = TextClock(this)
        date.format24Hour = "EEEE, d 'de' MMMM"
        date.format12Hour = "EEEE, d 'de' MMMM"
        date.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 18f)
        date.setTextColor(Color.parseColor("#B9CBFF"))
        left.addView(date)

        header.addView(left, LinearLayout.LayoutParams(0, WC, 1f))

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.END
        greeting = TextView(this)
        greeting.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 22f)
        greeting.setTextColor(Color.WHITE)
        greeting.gravity = Gravity.END
        right.addView(greeting)
        val club = TextView(this)
        club.text = "★  CRUZEIRO  ·  NAÇÃO AZUL  ★"
        club.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
        club.setTextColor(Color.parseColor("#9DB9FF"))
        club.letterSpacing = 0.2f
        club.gravity = Gravity.END
        right.addView(club)
        header.addView(right, LinearLayout.LayoutParams(WC, WC))

        col.addView(header, LinearLayout.LayoutParams(MP, WC))

        // Empurra o resto para baixo
        col.addView(View(this), LinearLayout.LayoutParams(MP, 0, 1f))

        // Tabela do Brasileirão + próximo jogo
        info = InfoCards(this, Handler(Looper.getMainLooper()))
        val infoRow = LinearLayout(this)
        infoRow.orientation = LinearLayout.HORIZONTAL
        infoRow.setPadding(dp(10), 0, dp(10), 0)
        infoRow.addView(info.standingsView, LinearLayout.LayoutParams(0, dp(112), 1f))
        val gameLp = LinearLayout.LayoutParams(0, dp(112), 1.1f)
        gameLp.leftMargin = dp(14)
        infoRow.addView(info.gameView, gameLp)
        col.addView(infoRow, LinearLayout.LayoutParams(MP, WC))

        col.addView(View(this), LinearLayout.LayoutParams(MP, dp(14)))

        // Favoritos
        col.addView(sectionLabel("FAVORITOS   ·   segure o OK em um app para favoritar ou remover"))
        favRow = LinearLayout(this)
        favRow.orientation = LinearLayout.HORIZONTAL
        favRow.clipChildren = false
        favRow.clipToPadding = false
        col.addView(scroller(favRow), LinearLayout.LayoutParams(MP, WC))

        col.addView(View(this), LinearLayout.LayoutParams(MP, dp(10)))

        // Todos os apps
        col.addView(sectionLabel("TODOS OS APPS"))
        allRow = LinearLayout(this)
        allRow.orientation = LinearLayout.HORIZONTAL
        allRow.clipChildren = false
        allRow.clipToPadding = false
        col.addView(scroller(allRow), LinearLayout.LayoutParams(MP, WC))

        setContentView(root)
    }

    private fun sectionLabel(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
        t.setTextColor(Color.parseColor("#8FB0FF"))
        t.letterSpacing = 0.25f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setPadding(dp(10), 0, 0, 0)
        return t
    }

    private fun scroller(inner: LinearLayout): HorizontalScrollView {
        val s = HorizontalScrollView(this)
        s.isHorizontalScrollBarEnabled = false
        s.clipChildren = false
        s.clipToPadding = false
        s.setPadding(dp(10), dp(12), dp(10), dp(12))
        s.addView(inner, FrameLayout.LayoutParams(WC, WC))
        return s
    }

    private fun updateGreeting() {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        greeting.text = when {
            h < 5 -> "Boa madrugada"
            h < 12 -> "Bom dia"
            h < 18 -> "Boa tarde"
            else -> "Boa noite"
        }
    }

    // ---------------------------------------------------------------- dados

    private fun loadApps() {
        val pm = packageManager
        val seen = HashSet<String>()
        val list = ArrayList<AppItem>()
        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        for (cat in categories) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg)
                    ?: continue
                val label = ri.loadLabel(pm).toString()
                val icon = ri.loadIcon(pm)
                val banner: Drawable? = try {
                    ri.activityInfo.loadBanner(pm)
                } catch (e: Exception) {
                    null
                }
                list.add(AppItem(label, pkg, icon, banner, launch))
            }
        }
        list.sortBy { it.label.lowercase() }
        apps = list
    }

    private fun getFavs(): MutableList<String> {
        val sp = getSharedPreferences(PREFS, MODE_PRIVATE)
        val saved = sp.getString(KEY_FAV, null)
        if (saved == null) {
            val installed = apps.map { it.pkg }.toSet()
            val def = PREFERRED.filter { it in installed }.take(MAX_FAVS).toMutableList()
            if (def.isEmpty()) def.addAll(apps.take(MAX_FAVS).map { it.pkg })
            return def
        }
        return saved.split(",").filter { it.isNotEmpty() }.toMutableList()
    }

    private fun saveFavs(list: List<String>) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_FAV, list.joinToString(","))
            .apply()
    }

    private fun toggleFav(a: AppItem) {
        val favs = getFavs()
        if (favs.contains(a.pkg)) {
            favs.remove(a.pkg)
            toast("Removido dos favoritos")
        } else if (favs.size >= MAX_FAVS) {
            toast("Máximo de $MAX_FAVS favoritos. Remova um antes (segure OK nele).")
            return
        } else {
            favs.add(a.pkg)
            toast("Adicionado aos favoritos")
        }
        saveFavs(favs)
        lastFocusPkg = a.pkg
        render()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------- desenho das linhas

    private fun render() {
        favRow.removeAllViews()
        allRow.removeAllViews()

        val byPkg = apps.associateBy { it.pkg }
        val favPkgs = getFavs().filter { byPkg.containsKey(it) }
        val gap = dp(14)

        var target: View? = null

        for ((i, p) in favPkgs.withIndex()) {
            val a = byPkg[p] ?: continue
            val v = favCard(a)
            val lp = LinearLayout.LayoutParams(cardW, cardH)
            if (i > 0) lp.leftMargin = gap
            favRow.addView(v, lp)
            if (p == lastFocusPkg) target = v
        }

        val favSet = favPkgs.toSet()
        var n = 0
        for (a in apps) {
            if (a.pkg in favSet) continue
            val v = smallTile(a)
            val lp = LinearLayout.LayoutParams(dp(92), WC)
            if (n > 0) lp.leftMargin = dp(12)
            allRow.addView(v, lp)
            if (a.pkg == lastFocusPkg) target = v
            n++
        }

        val toFocus: View? = target
            ?: (if (favRow.childCount > 0) favRow.getChildAt(0) else null)
            ?: (if (allRow.childCount > 0) allRow.getChildAt(0) else null)
        toFocus?.requestFocus()
    }

    private fun fill(radius: Int): StateListDrawable {
        val normal = GradientDrawable()
        normal.cornerRadius = radius.toFloat()
        normal.setColor(Color.parseColor("#26FFFFFF"))
        val focused = GradientDrawable()
        focused.cornerRadius = radius.toFloat()
        focused.setColor(Color.parseColor("#4DFFFFFF"))
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), focused)
        sl.addState(intArrayOf(), normal)
        return sl
    }

    private fun ring(radius: Int): StateListDrawable {
        val on = GradientDrawable()
        on.cornerRadius = radius.toFloat()
        on.setColor(Color.TRANSPARENT)
        on.setStroke(dp(3), Color.WHITE)
        val off = GradientDrawable()
        off.cornerRadius = radius.toFloat()
        off.setColor(Color.TRANSPARENT)
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), on)
        sl.addState(intArrayOf(), off)
        return sl
    }

    private fun roundOutline(radius: Int): ViewOutlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radius.toFloat())
        }
    }

    private fun wire(v: View, a: AppItem) {
        v.isFocusable = true
        v.isClickable = true
        v.isLongClickable = true
        v.tag = a.pkg
        v.setOnClickListener {
            try {
                startActivity(a.intent)
            } catch (e: Exception) {
                toast("Não foi possível abrir ${a.label}")
            }
        }
        v.setOnLongClickListener {
            toggleFav(a)
            true
        }
        v.setOnFocusChangeListener { view, hasFocus ->
            val s = if (hasFocus) 1.07f else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(120).start()
            if (hasFocus) lastFocusPkg = a.pkg
        }
    }

    private fun favCard(a: AppItem): View {
        val r = dp(16)
        val card = FrameLayout(this)
        card.background = fill(r)
        card.foreground = ring(r)
        card.elevation = dp(4).toFloat()

        val banner = a.banner
        if (banner != null) {
            val iv = ImageView(this)
            iv.setImageDrawable(banner)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.outlineProvider = roundOutline(r)
            iv.clipToOutline = true
            card.addView(iv, FrameLayout.LayoutParams(MP, MP))
        } else {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            val iv = ImageView(this)
            iv.setImageDrawable(a.icon)
            box.addView(iv, LinearLayout.LayoutParams(dp(56), dp(56)))
            val t = TextView(this)
            t.text = a.label
            t.setTextColor(Color.WHITE)
            t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.setPadding(dp(8), dp(6), dp(8), 0)
            box.addView(t, LinearLayout.LayoutParams(MP, WC))
            card.addView(box, FrameLayout.LayoutParams(MP, MP))
        }
        wire(card, a)
        return card
    }

    private fun smallTile(a: AppItem): View {
        val r = dp(14)
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER_HORIZONTAL
        tile.setPadding(dp(6), dp(10), dp(6), dp(8))
        tile.background = fill(r)
        tile.foreground = ring(r)

        val iv = ImageView(this)
        iv.setImageDrawable(a.icon)
        tile.addView(iv, LinearLayout.LayoutParams(dp(48), dp(48)))

        val t = TextView(this)
        t.text = a.label
        t.setTextColor(Color.WHITE)
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11f)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(0, dp(6), 0, 0)
        tile.addView(t, LinearLayout.LayoutParams(MP, WC))

        wire(tile, a)
        return tile
    }
}
